##".onUnload" <-
##function(libpath)
##    library.dynam.unload("ada", libpath)

".noGenerics" <-
TRUE
