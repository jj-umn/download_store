"ada" <-
function(x,...)UseMethod("ada")

